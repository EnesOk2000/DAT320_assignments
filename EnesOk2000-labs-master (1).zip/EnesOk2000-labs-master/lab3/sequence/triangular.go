package sequence

import "fmt"

func triangular(n uint) uint{
	return n*(n+1)/2
}

func sequence() {
	fmt.Println(triangular(20))
}
