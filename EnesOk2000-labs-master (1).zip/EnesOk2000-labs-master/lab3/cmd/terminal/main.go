package main

import (
	"strings"
	"os"
	"log"
	"io/ioutil"
	"fmt"
	"bufio"
)

func main() {
	reader := bufio.NewReader(os.Stdin)
	for {
		dir, err := os.Getwd()
		if err != nil {fmt.Println("")}
		fmt.Print(dir, "$ ")
		cmdString, err := reader.ReadString('\n')
		if err != nil {fmt.Fprintln(os.Stderr, err)}
		runCommand(cmdString)
	}
}

func runCommand(commandStr string) {
	commandStr = strings.TrimSuffix(commandStr, "\n")
	arrCommandStr := strings.Fields(commandStr)
	switch arrCommandStr[0] {
	case "exit":
		os.Exit(0)
	case "help":
		help()
	case "ls":
		ls()
	case "cd":
		cd(arrCommandStr[1])
	case "mkdir":
		mkdir(arrCommandStr[1])
	case "create":
		create(arrCommandStr[1])
	case "rm":
		rm(arrCommandStr[1])
	default:
		fmt.Println("Command not recognized.")
	}
}

func help() {fmt.Println("The help is here!")}

func ls() {
	files, err := ioutil.ReadDir(".")
	if err != nil {fmt.Println(err)}
	for _, file := range files {fmt.Println(file.Name())}
}

func cd(path string) {
	err := os.Chdir(path)
	if err == nil {fmt.Println(path)}
}

func mkdir(path string) {
	fmt.Println(path)
	err := os.Mkdir(path, 0700)
	if err != nil {log.Fatal(err)}
}

func rm(path string) {
	e := os.RemoveAll(path)
	if e != nil {log.Fatal(e)}
}

func create(path string) {
	g, err := os.Create(path)
	if err != nil {
		fmt.Println(err, g)
		return
	}
}