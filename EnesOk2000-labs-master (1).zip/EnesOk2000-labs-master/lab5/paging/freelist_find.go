package paging

// findFreeFrames returns indices for n free frames.
// If there are not enough free frames available, an error is returned.
func (fl *freeList) findFreeFrames(n int) ([]int, error) {
	return []int{}, errNotImplemented
}
