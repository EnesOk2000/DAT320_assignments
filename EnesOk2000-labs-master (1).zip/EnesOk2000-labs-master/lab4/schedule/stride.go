package schedule

import "time"

// strideScheduler may be defined as an alias for rrScheduler; it has the same fields.
type strideScheduler struct {
	baseScheduler
	Quantum time.Duration
}

// newStrideScheduler returns a stride scheduler.
// With this scheduler, jobs are executed similar to round robin,
// but with exact proportions determined by how many tickets each job is assigned.
func newStrideScheduler(quantum time.Duration) *strideScheduler {
	return &strideScheduler{
		Quantum: quantum,
		baseScheduler: baseScheduler{
			runQueue:  make(chan job, queueSize),
			completed: make(chan result, queueSize),
			jobRunner: func(job job) {
				job.run(quantum)
			},
		},
	}
}

// schedule schedules the provided jobs according to a stride scheduler's order.
// The task with the lowest pass is scheduled to run first.
func (s *strideScheduler) schedule(inJobs jobs) {
	ant := 0
	for {
		number := minPass(inJobs)
		if inJobs[number].remaining == time.Duration(-100) {
			inJobs[number].pass = 1000000
			continue
		}
		if inJobs[number].remaining > time.Duration(0) {
			s.runQueue <- inJobs[number]
			inJobs[number].pass += inJobs[number].stride
			inJobs[number].remaining -= s.Quantum
		} else { 
			ant += 1 
			inJobs[number].remaining = time.Duration(-100)
			if ant == len(inJobs) {break}
			continue
		}
		if ant == len(inJobs) {break}
	}
	close(s.runQueue)
}

<<<<<<< HEAD
// minPass returns the numberex of the job with the lowest pass value.
func minPass(theJobs jobs) int {
	numberex_smallest := 0
	value_smallest := 100000
	stride_value_smallest := 100000
	for z, job := range theJobs {
		if job.pass == value_smallest {
			if job.stride < stride_value_smallest {
				numberex_smallest = z
				value_smallest = job.tickets
			}
		}
		if job.pass < value_smallest {
			numberex_smallest = z
			value_smallest = job.pass
			stride_value_smallest = job.stride
		}
	}
	return numberex_smallest
=======
// minPass returns the index of the job with the lowest pass value.
func minPass(theJobs jobs) int {
	//TODO(student) implement minPass and use it from schedule()
	// You need to keep track of both the lowest pass value and its index.
	lowest := 0
	return lowest
>>>>>>> 3b698e34f4be91e24248f25b0fe213b324e2b6aa
}
