package schedule

import (
	"time"
)

type rrScheduler struct {
	baseScheduler
	//TODO(student) add missing fields, if necessary
	Quantum time.Duration
}

// newRRScheduler returns a Round Robin scheduler with the time slice, quantum.
func newRRScheduler(quantum time.Duration) *rrScheduler {
	//TODO(student) construct new RR scheduler
	return &rrScheduler{
		Quantum: quantum,
		baseScheduler: baseScheduler{
			runQueue:  make(chan job, queueSize),
			completed: make(chan result, queueSize),
			jobRunner: func(job job) {
				job.run(quantum)
			}, 
		}, 
	} 
}

// schedule schedules the provided jobs in round robin order.
func (s *rrScheduler) schedule(jobs jobs) {
	var check []time.Duration
	ant := 0
	mjobs := jobs
	for _, job := range jobs {check = append(check, job.estimated)}
	for {
		for z, job := range mjobs {
			if check[z] == time.Duration(-100) {continue}
			if check[z] > time.Duration(0) {
				s.runQueue <- job
				check[z] -= s.Quantum
			} else {
				ant += 1
				check[z] = time.Duration(-100)
				if ant == len(jobs) {break}
				continue
			}
		}
		if ant == len(jobs) {break}
	}
	close(s.runQueue)
}
