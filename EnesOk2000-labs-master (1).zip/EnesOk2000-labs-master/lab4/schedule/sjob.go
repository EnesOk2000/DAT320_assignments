package schedule

import "time"

// newSJob creates a job entry for stride scheduling.
func newSJob(id, tickets int, estimated time.Duration) job {
	const numerator = 10000
	//TODO(student) finish the sjob constructor
	return job{
		stride:    numerator / tickets,
		pass:      0,
		tickets:   tickets,
		doJob:     time.Sleep,
		remaining: estimated,
		scheduled: estimated,
		estimated: estimated,
		id:        id,
	}
}
