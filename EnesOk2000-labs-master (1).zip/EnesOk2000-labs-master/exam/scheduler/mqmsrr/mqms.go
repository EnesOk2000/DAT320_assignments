package mqmsrr

import (
	"dat320/exam/scheduler/cpu"
	"dat320/exam/scheduler/job"
	"dat320/exam/scheduler/config"
	"time"
)

// Multi-queue multiprocessor scheduler (MQMS)
type multiQueueScheduler struct {
	m	[]mqState
	qu	time.Duration
	c	time.Duration
}

func New(cpus []*cpu.CPU, quantum time.Duration) *multiQueueScheduler {
	var o []mqState
	for _, cpu := range cpus {
		o = append(o, *NewMQState(cpu))
	}
	return &multiQueueScheduler{
		m:	o,
		qu:	quantum,
		c:	0,
	}
}

// Add jobs to queue and set arrival time for the job.
// The job is added to exactly one queue with the fewest jobs.
// The choice of shortest queue should be deterministic, starting from CPU0 and up.
func (q *multiQueueScheduler) Add(job *job.Job) {
	if 2 > len(q.m) {
		q.m[0].Add(job)
	} else {
		var k int = 0
		var sq int = 999999
		for ooo := range q.m {
			if sq > len(q.m[ooo].queue) {
				k = ooo
				sq = len(q.m[ooo].queue)
			}
		}
		q.m[k].Add(job)
	}
}

// Tick runs the scheduled jobs for the system time on all CPUs, and returns
// the number of jobs finished in this tick. Depending on scheduler requirements,
// the Tick method may assign new jobs to the different CPUs before returning.
func (q *multiQueueScheduler) Tick(systemTime time.Duration) int {
	/* jobsFinished := 0
	for g := range q.m {
		if len(q.m[g].queue) == 0 {return jobsFinished}
    	if q.m[g].cpu.IsRunning(){
       		if q.m[g].Tick(){jobsFinished++}
			   q.c += config.TickDuration
   		}
		q.m[g].Reassign()	
	}
	return jobsFinished*/
	jobsfinished := 0
	q.c += config.TickDuration
	for g := range q.m {
		if q.m[g].cpu.IsRunning() {
			if q.m[g].Tick() {
				jobsfinished++
				q.m[g].Reassign()
			} else if q.c >= q.qu {
				q.m[g].Reassign()
			}
		} else {
			
			q.m[g].Reassign()
		}
	}
	return jobsfinished
}
