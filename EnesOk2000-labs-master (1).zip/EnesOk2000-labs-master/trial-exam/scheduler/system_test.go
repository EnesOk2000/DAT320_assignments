package scheduler

import (
	"dat320/trial-exam/scheduler/config"
	"dat320/trial-exam/scheduler/cpu"
	"dat320/trial-exam/scheduler/fifo"
	"dat320/trial-exam/scheduler/job"
	"dat320/trial-exam/scheduler/rr"
	"testing"
)

const (
	t005 = config.T005
	t010 = config.T010
	t020 = config.T020
)

func TestFIFOSystem(t *testing.T) {
	job.ResetJobCounter()
	schedule := []*entry{
		e(10, t010, t005), // a
		e(10, t010, t005), // b
		e(10, t010, t010), // c
		e(10, t010, t010), // d
		e(10, t020, t010), // e
	}
	cpu := cpu.NewCPUs(1, 0)
	scheduler := fifo.New(cpu[0])
	sys := NewSystem(scheduler, cpu)
	sys.Run(schedule)
}

func TestRoundRobinSystem(t *testing.T) {
	job.ResetJobCounter()
	schedule := []*entry{
		e(10, t010, t005), // a
		e(10, t010, t005), // b
		e(10, t010, t010), // c
		e(10, t010, t010), // d
		e(10, t020, t010), // e
	}
	cpu := cpu.NewCPUs(1, 0)
	scheduler := rr.NewRoundRobin(cpu[0], t010)
	sys := NewSystem(scheduler, cpu)
	sys.Run(schedule)
}
