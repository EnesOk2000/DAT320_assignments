package scheduler

import (
	"dat320/trial-exam/scheduler/job"
	"time"
)

type entry struct {
	job     *job.Job
	arrival time.Duration
}

// e is a helper function to create a scheduling entry with a job and its arrival time.
// The job has some size and an estimated running time.
var e = func(size int, estimated, arrival time.Duration) *entry {
	return &entry{job: job.New(size, estimated), arrival: arrival}
}
