package scheduler

import (
	"dat320/trial-exam/scheduler/job"
	"time"
)

type Scheduler interface {
	Add(*job.Job)
	Tick(time.Duration) int
}
