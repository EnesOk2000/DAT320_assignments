package rr

import (
	"dat320/trial-exam/scheduler/cpu"
	"dat320/trial-exam/scheduler/job"
	"dat320/trial-exam/scheduler/config"
	"time"
)

type roundRobin struct {
	cpu   *cpu.CPU
	queue job.Jobs
	quantum time.Duration
	teller time.Duration
}

func NewRoundRobin(c *cpu.CPU, quantum time.Duration) *roundRobin {
	return &roundRobin{
		cpu:   c,
		queue: make(job.Jobs, 0),
		quantum: quantum,
	}
}

func (rr *roundRobin) Add(job *job.Job) {
	rr.queue = append(rr.queue, job)
}

func (rr *roundRobin) remove() *job.Job {
	if len(rr.queue) == 0 {
		return nil
	}
	removedJob := rr.queue[0]
	rr.queue = rr.queue[1:]
	return removedJob
}

// reassign finds a new job to run on this CPU
func (rr *roundRobin) reassign() {
	nxtJob := rr.remove()
	rr.cpu.Assign(nxtJob)
}

func (rr *roundRobin) Tick(systemTime time.Duration) int {
	jobsFinished := 0
	if rr.cpu.IsRunning() {
		if rr.quantum > rr.teller {
			if rr.cpu.Tick() {
				rr.teller = config.T000
				jobsFinished++
				rr.reassign()
			} else {
				rr.teller += config.TickDuration
			}
		} else {
			rr.teller = config.T000
			var job_now = rr.cpu.CurrentJob()
            rr.Add(job_now)
		}
	} else {
		// CPU is idle, find new job in own queue
		rr.reassign()
	}
	return jobsFinished
}

// do one job for set amount of time.
// if job finished ++ and remove job from queue.
// if time is up remove job from queue and append it back in.
