package fifo

import (
	"dat320/trial-exam/scheduler/cpu"
	"dat320/trial-exam/scheduler/job"
	"time"
)

type fifo struct {
	cpu   *cpu.CPU
	queue job.Jobs
}

func New(c *cpu.CPU) *fifo {
	return &fifo{
		cpu:   c,
		queue: make(job.Jobs, 0),
	}
}

func (f *fifo) Add(job *job.Job) {
	f.queue = append(f.queue, job)
}

func (f *fifo) remove() *job.Job {
	if len(f.queue) == 0 {
		return nil
	}
	removedJob := f.queue[0]
	f.queue = f.queue[1:]
	return removedJob
}

// reassign finds a new job to run on this CPU
func (f *fifo) reassign() {
	nxtJob := f.remove()
	f.cpu.Assign(nxtJob)
}

func (f *fifo) Tick(systemTime time.Duration) int {
	jobsFinished := 0
	if f.cpu.IsRunning() {
		if f.cpu.Tick() {
			jobsFinished++
			f.reassign()
		}
	} else {
		// CPU is idle, find new job in own queue
		f.reassign()
	}
	return jobsFinished
}
