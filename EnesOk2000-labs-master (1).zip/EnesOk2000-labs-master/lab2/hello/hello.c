#include <stdio.h>

int main(int argc, char* argv[])
{
	// TODO: Implement program
	if(argc==1){
		printf("Hello, world!\n");
	}
	if(argc>1){
		for (int i = 1; i < argc; i++){
        		printf("Hello, %s!\n",argv[i]);
		}
	}	
	return 0;
}
